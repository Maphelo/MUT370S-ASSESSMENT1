<footer class="site-footer">

<nav class="site-nav">
        <?php 
            $args = array('theme_location' => 'seconds');
        ?>
        <?php wp_nav_menu($args); ?>
</nav>
<p><?php bloginfo('Felicity Media House'); ?> - &copy; <?php echo date('2019'); ?></p>
<?php wp_footer(); ?>
<footer class="container-fluid db-3 text-center">
    <p>Facebook:<a href="https://www.facebook.com/nomaphelo.mkutu">Maphelo Mkutu</a></p>
    <p>Contact No:0744393254</p>
    &copy;Felificity Media House 2019; 
</footer>
</footer>
</body>
</html>